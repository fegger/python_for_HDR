# -*- coding: utf-8 -*-
"""
Created on Wed Nov 10 14:45:23 2021

@author: Felix Egger

Adapted from ENGG1001 tutorials by Kate O'Brien.

This script introduces packages for data analysis:
    - numpy (Array operation)
    - pandas (DataFrames, import data)
    - matplotlib (Plotting)

The data for this is flows.csv, a data set of the Wivenhoe and Somerset
reservoir systems. The data set is large, with daily samples ranging from
1980-01-01 to 2010-03-31.

The script follows a basic data analysis pathway that can be adapted to the
task at hand:
    1. Inspect and clean data, check assumptions
    2. Formulate a question and hypotheses
    3. Do the analysis (hypothesis test)
    4. Make a decision about the hypotheses
    5. Answer the question
    6. Ask more questions
"""

#%% 0. IMPORT THE REQUIRED PACKAGES

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
