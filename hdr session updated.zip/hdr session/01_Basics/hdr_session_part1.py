# -*- coding: utf-8 -*-
"""
Created on Wed Nov  3 09:29:25 2021

@author: Felix Egger

This python script is designed to teach the very basics of python in an
interactive way. The code is structured into cells deliniated by horizontal
lines. Cells can be collapsed if necessary by clicking directly left to the
code.

The whole unit consists of ten sections. In part 1 we explore the first 4.

    0. Importing functionality
    1. Python as a calculator, variable assignment and Variable Explorer
    2. Basic data types in python
    3. Basic iterable data types, indexing and slicing

PART 1:

Run code line by line. Click anywhere on the line you want to run and press the
Run selction or current line button. You can also press F9.
No need to run comment lines (lines with preceeding #)
"""

#%% Code cells are created with a #%% symbol. It helps break the code into blocks
# and code cells can be executed individually.
#
# Comments are written with a hash (#) symbol. Comments are not executed when
# the program runs.
#%% Section 0 Exercises: Importing

# Python comes with basics of how code is organised, some basic functions,
# object oriented programming approaches, among other things.
# If we want any other kind of functionality, we need to import modules.
# For example, to be able to work with pi, use the exponential function, etc.
# we need to import math:

import math

# After the module is imported, we can access functions, attributes and submodules.
# The syntax for this is:
#   math.pi
#   math.exp(5)

# 1. Try to run the following lines (Press F9) or paste them to the console.

math.pi
math.exp(5)

# Specific functions can be imported as follows (if the whole module is not of
# interest):

from math import log

# After the specific function is imported it can be used without the dot
# operator:

# 2. Run the follwoing in the Console after importing log from math

log(10)

# Imported modules and functions can be aliased to minimize typing:

# 3. Import the numpy module:

import numpy as np

# 4. Create a 1-D array of zeros with length 2:

np.zeros(2)

#%% Section 1 Exercises: Calculator and Variables

# 1. What is the result of the following operation?

5 * 2 + 22 / 2

# 2. Check the output in the console. Why is the output 21.0 not 21?

# 3. Assign the operation to the variable result:

result = 5 * 2 + 22 / 2

# 4. Check the Variable explorer. What is the type of result?

#%% Read more about: Numeric data types and Numeric operators in python

# Other than int (integer aka whole number) and float (floating point number),
# python also has a data type for complex numbers (complex). The imaginary
# number is j.
#
# E.g.: 3 + 5j
#
# The / operator is a floating point division which always results in a floating
# point number
# Other operators are:
#   Subtraction: - (e.g. 5 - 3 = 2)
#   Exponentiation: ** (e.g. 5 ** 2 = 25, 25 ** 0.5 = 5.0)
#   Integer (floor) division: // (e.g. 8 // 10 = 0, 25 // 2 = 12)
#   Modulo: % (e.g. 25 % 2 = 1)
# All operators have an inplace operator as well:
#   x = x + y can be simplified to x += y
#   the sum of x and y is reassigned to x

#%% Section 2 Exercises: Basic data types

# 1. What is the output of the following operation?

int(result)

# 2. Check the data type of result in the Variable Explorer. Why did it not change?

# 3. What is the result of the following operation?

string = str(result)

# 4. Check the type and size in the Variable Explorer.

# 5. What is the result of the following comparison?

comparison = string == result

# 6. What is the data type of comparison? Why did it return False?

#%% Read more about: Comparison and boolean operators in python

# Strictly greater than: >
# Strictly less than: <
# Less than or equal: <=
# Greater than or equal: >=
# Equal: ==
# Not equal: !=
# Object identity: is
# Negated onject identity: is not
# Boolean OR: or (e.g. x or y: if x is false, then y, else x)
# Boolean AND: and (e.g. x and y: if x is false, then x, else y)
# Boolean NOT: not (e.g. not x: if x is false, then True, else False)

# Python stores numerical data which means that exact equality comparisons
# can sometimes not be made. The math and numpy modules have a numerical
# comparison, using a specified tolerance (defaults: abs_tol = 0.0, rel_tol = 1e-9):
#
# math.isclose(equality comparison)
# np.isclose(equality comparison)
#

#%% Section 3 Exercises: Iterable data types and indexing/slicing

# 1. What is the result of the following operation?

collection = list(string)

# 2. Check the data type in the variable explorer. What is the size of collection?

# 3. Create a list by enclosing the elements in square brackets separated by a comma
#    Data types in the list can be mixed

temperature = ['station_1',28.0, 27.1, 30.3, 29.5]

# 4. What is the output of the following code?

temperature[0]

# 5. What is the output of the following code?

temperature[0:4]

# 6. Complete the code below to extract [28.0, 27.1, 30.3, 29.5] from temperature

temperature[:5]

# 7. What is the result of the following code?

temperature[0:5:2]

# 8. What did the aboce slice do?

# 9. What is the result of the following code?

stations = [[],[]]
stations[0] = temperature
stations[1] = ['station_2',26.4, 27.1, 28.3, 29.9]

# 10. Change the following code to extract the last temperature from station 2

stations[1][4]

# 11. What is the output of the following code

stations[0][1] = 27.8

#%% Read more about: Iterable data types and slicing

# Lists are mutable sequences which means items in the list can be reassigned
# The other main iterable data type is a tuple:
#    Intialise an empty tuple with: t = ()
#    A tuple is characterised by commas separating items: t = 4, 5, 6
#    The assignment t = (4) result in an int data type
#    The assignment t = (4,) results in a tuple data type
#    Tuples are immutable. Items in the tuple cannpot be replaced by indexing:
#    t = 4, 5, 6
#    t[0] = 1 --> will result in a TypeError
#
# Slicing: A slice of an iterable piece of data is a subset of the entire
# sequence. Python slices are copies of the original data.
#    * A slice generally is: iterable[start_index:end_index_exclusive:step]
#    * The default step is 1
#    * If the end_index is unknown it can be skipped: iterable[3:] starts at the
#       fourth element and ends at the last element
#    * Indeces can be negative as well: the last index in a sequence is:
#        sequence[-1]
#    * Easily reverse a sequence by using a negative step leaving start and
#       end index empty: sequence[::-1]
