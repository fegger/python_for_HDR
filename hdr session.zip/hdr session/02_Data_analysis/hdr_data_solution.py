# -*- coding: utf-8 -*-
"""
Created on Wed Nov 10 14:45:23 2021

@author: Felix Egger

Adapted from ENGG1001 tutorials by Kate O'Brien.

This script introduces packages for data analysis:
    - numpy (Array operation)
    - pandas (DataFrames, import data)
    - matplotlib (Plotting)

The data for this is flows.csv, a data set of the Wivenhoe and Somerset
reservoir systems. The data set is large, with daily samples ranging from
1980-01-01 to 2010-03-31.

The script follows a basic data analysis pathway that can be adapted to the
task at hand:
    1. Inspect and clean data, check assumptions
    2. Formulate a question and hypotheses
    3. Do the analysis (hypothesis test)
    4. Make a decision about the hypotheses
    5. Answer the question
    6. Ask more questions
"""

#%% 0. IMPORT THE REQUIRED PACKAGES

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#%% 1. LOCATE DATA, INSPECT DATA, CLEAN DATA, CHECK ASSUMPTIONS

# We are using pandas to read in the csv file. Pandas data types are DataFrames
# which are very similar to the data frames in R, and Excel tables:

# pd.read_csv has multiple inputs. Check what they are by clicking the cursor
# on read_csv and type Ctrl+I.

# The first input is the filename or the path to the file with the file name

data = pd.read_csv('flows.csv')

# There are also methods to read txt files (read_txt) and you can read Excel
# files directly (read_excel).
# After you have read in the data, inspect it in the Variable Explorer.
# Check the head of the data (First 5 lines of the table). Use the DataFrame
# head() method. Make sure to print to the console.

print(data.head())

# Check if there are any entries in the data frame that are N/A (not a number)
# Use the DataFrame isna() and any() methods for this. Make sure to print the
# result to the console.

print(data.isna().any())

# Most statistical analysis requires the data to be normally distributed. We can
# use quick DataFrame methods to draw histograms and boxplots. The plots will
# render in the Plots pane on the right.

data.hist()
data.boxplot()

#%% BETTER PLOTTING
# Both plots are not very revealing. Setting the scale on the y-axis to
# logarithmic could help to better visualise the data.
# We will use matplotlib (Object Oriented Plotting) to do this.

# Matplotlib figures start with setting up a figure and axis object:

fig, ax = plt.subplots()

# Next we use the axis object to plot a boxplot into the figure. The input for
# this is the DataFrame, but only the flow data, not the date

ax.boxplot(data.drop('Date', axis = 1))

# Next we want to set the scale on the y-axis to logarithmic:

ax.set_yscale('log')

# Next we will set proper ticks on the x-axis, and labels on all axes:

ax.set_xticklabels(['S, in', 'S, out', 'UBR', 'W, out',])
ax.set_xlabel('Stream')
ax.set_ylabel('Flow (ML)')

# The subplots command can take a shape (rows, columns) to make multiple subplots
# Try to make a figure with 2 rows and 2 columns of subplots:

# fig, ax = plt.subplots(2,2)

# Now we can save the figure:
fig.savefig('flow_boxplot.png')

#%% 2. FORMULATE A QUESTION AND HYPOTHESES

# An interesting question for this system would be:
#   What is the relative accumulation in each reservoir and are they different
#   from each other over the study period?

# For example: The regulator wants to allow water extraction from both
# reservoirs. The regulator decides to allow the same water allocations for
# both reservoirs. We want to find out if the relative accumulations in both
# reservoirs are actually similar, or if two different water allocation
# strategies are necessary.

#%% 3. DO THE ANALYSIS

# For this we need to know what the Wivenhoe inflow is. We know from the map
# that the inflow to Wivenhoe comes from Somerset and the Upper Brisbane River.

# Indexing a DataFrame to extract a column is a good way but
# first we will use numpy arrays (matrix package) to do this:

# First, we need to convert the DataFrame into an array:

array = np.array(data)

# Now, we can index the columns to find the relevant flows:

s_out_array = array[:,2]
ubr_array = array[:,3]

# The above is to illustrate how similar numpy is to working with lists etc.
# We can, however, directly use the DataFrame to get the same info. The DataFrame
# is indexed with the column name to extract the same information.
# Only the data type is different between the two approaches:
#   numpy: array
#   pandas: Series

s_out = data['Somerset outflow, ML']
ubr = data['Upper Brisbane River, ML']

# We can use numpy here (even though we are not using it directly), to add the
# two columns elment wise. Element wise operation is default in numpy and pandas
# as opposed to MATLAB (even for multiplication etc.)

w_in = s_out + ubr

# Next we are interested in the relative accumulation as a time series. We need
# the Wivenhoe outflow and the Somerset inflow:

w_acc = w_in - data['Wivenhoe outflow, ML']
s_acc = data['Somerset inflow, ML'] - s_out

# To get an overview of what this looks like we can plot a timeseries for each:

w_acc.plot()
s_acc.plot()

# Next we want to find the means and spread of each accumulation and compare
# them as an indication of their similarity.
# We can use Series methods from pandas to get the mean and the standard error
# in the mean: column.mean(), column.sem()

print(w_acc.mean(), '+/-', w_acc.sem())
print(s_acc.mean(), '+/-', s_acc.sem())

# We could then do an independent t-test here to see if there is a statistical
# difference between the two values

#%% 4. MAKE A DECISION ABOUT THE HYPOTHESES

# Statistical tests and other statistical methods as well as distributions
# can be found in the scipy.stats module and the statsmodels package:

# import scipy.stats as st
# import statsmodels as stm

# An independent t-test can be run as follows:
#st.ttest_ind(w_acc, s_acc)

#%% 5. ANSWER THE QUESTION

# What do you think? Based on the data, is it reasonable to use the same water
# allocation for Wivenhoe and Somerset?

#%% 6. ASK MORE QUESTIONS

# What are any other questions about the data set?
# Some ideas: High flow and low flow events, drought years, etc.
