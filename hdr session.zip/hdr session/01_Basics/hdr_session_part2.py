# -*- coding: utf-8 -*-
"""
Created on Wed Nov  3 09:29:25 2021

@author: Felix Egger

This python script is designed to teach the very basics of python in an
interactive way. The code is structured into cells deliniated by horizontal
lines. Cells can be collapsed if necessary by clciking directly left to the
code.

The whole unit consists of ten sections. In part 2 we explore the last 6.

    4. Iteration and scoping by indentation, for loops
    5. Iteration and scoping by indentation, ranges
    6. Iteration and scoping by indentation, enumerate
    7. Logic branching and scoping by indentation
    8. Functional decomposition, function definition
    9. Functional decomposition, using functions

PART 2:

Run code by cell. Click anywhere between to horizontal lines to activate a code
cell. Click the RUn current cell button or Ctrl+Enter to run the current cell.
No need to run comment cells (Cells containing lines preceeding only with #).

"""
#%% Code cells are created with a #%% symbol. It helps break the code into blocks
# and code cells can be executed individually.
#
# Comments are written with a hash (#) symbol. Comments are not executed when
# the program runs.

#%% Import:
# we want to reuse the data from part 1 but don't necessarily want to run the
# file from part 1 again. Instead we can make use of the python import
# functionality:

import hdr_session_part1 as hdr

# Now we can get the temperature list from the hdr module and assign it to
# the variable temperature:

temperature = hdr.temperature

# THIS ONLY WORKS IF PYTHON KNOWS WHERE THE FILE hdr_session_part1.py IS
# LOCATED. CHNAGE THE DIRECTORY TO THE WHERE BOTH FILES ARE LOCATED.

#%% Alternatively we can specify the import if we are not iterested in
#importing the entuire module:

# from hdr_session_part1 import temperature

# THIS ONLY WORKS IF PYTHON KNOWS WHERE THE FILE hdr_session_part1.py IS
# LOCATED. CHNAGE THE DIRECTORY TO THE WHERE BOTH FILES ARE LOCATED.

#%% Section 4 Exercises: Iteration and Indentation: Part 1

# 1. Run the cell. What is the error message in the console and why does the
# error happen?

# 2. Change the following code to make it work (Hint: hover over the red x next
#    to line 66)

print('start')
for element in temperture:
    print(element)
    print('-----')
print('end')

# 3. What is the result of the above code when the code cell is executed
#    without errors?

# 4. Analyse the code: What does the print function do?

# 5. Analyse the code: How did the python interpreter know which lines to
#    iterate over and which lines are not part of the iteration?

#%% Section 5 Exercises: Iteration and Indentation: Part 2

# 1. What is result of the following code?

for idx in range(10):
    print(idx)

# 2. What does the range function do?

# 3. Type range( into the Console and observe the tool tip. How could the range
#    start at 1?

# 3. Change the above code so that the range starts at 1 and ends at 10. Rerun
#    the cell.

#%% Section 6 Exercises: Iteration and Indentation: Part 3

# 1. What is the result of the following code?

for index, element in enumerate(temperature):
    print(index)
    print(element)
    print('-----')

# 2. Analyse the code and the output. What does the enumerate function do?

#%% Section 7 Exercises: Logic and Indentation

# 1. What is the result of the following code?

for index, element in enumerate(temperature):
    if element == 'station_1':
        print(index, 'Station identifier')
    elif element > 30:
        print(index, 'Larger than 30')
    else:
        print(index, 'Smaller than 30')

# 2. Change the above code to check if the element is larger than 28 and
#    chnage the print statement to reflect this change

# 3. How did the python interpreter know what part of the code belonged to the
#    iteration and the logic test?

# 4. Write code to incorporate an additional test to check if the temperature
#    is smaller than 27. Adjust the print statements accordingly.

#%% Read more about: Indentation, Loops and Logic

# Indentation:
# Indentation is the way to differentiate scopes in python. Every elemnt of the
# code belonging to the same scope, has to be indented at the same level
# (even comments!)
# A new scope starts after : and code is indented from there.
#
# Loops: Used to execute code repeatedly
#   * for: a for loop should be used for stepping through a sequence.
#       Syntax: for element in sequence:
#       Sometimes the element AND the index of the sequence are required.
#       The enumerate() function can be used for this.
#       Syntax: for index, element in enumerate(sequence):
#
#   * while: a while loop should be used to repeat code as long as the
#            condition is True
#       Syntax: while condition is True:
#
# Logic: Used to execute specific parts of the code based on conditions
#   * if: the if statement starts a branch in the code.
#       Syntax: if condition is True:
#   * elif: the elif statement evaluates another condition (only after if)
#       Syntax: elif condition is True:
#   * else: the else statement evaluates in any other case
#       Syntax: else:

#%% Section 8 Exercises: Functions: Part 1

# 1. Run this code cell to define the following function

def convert_celsius_to_kelvin(temp):
    '''
    Function to convert temperatures from oC to K.

    Parameters
    ----------
    temp : float
        A temperature in degree Celsisus.

    Returns
    -------
    float
        Temperature converted to Kelvin.

    '''
    KELVIN = 273.15
    return temp + KELVIN

# 2. Analyse the code: Which part of the function is the:
#       * Doc-string?
#       * return statement?
#       * function body?
#       * function definition?

#%% Section 9 Exercises: Functions: Part 2

# 1. What is the result of the following operation?

converted_temperature = convert_celsius_to_kelvin(temperature[1])

# 2. Use the function convert_celsius_to_kelvin on line 193
#    in the for loop to print temperature in K.
#    Use the function and a print statement to achieve this. Remember to write
#    the code in the right scope (i.e. watch out for indentation)

print('start')
for index, element in enumerate(temperature, start=1):

    print('-----')
print('end')

# 3. Analyse the code: What does start=1 in the enumerate function do?

# 4. Change the code to start the enumeration at 0. What is the error python
#    returns? Why does python return this error?

#%% CONGRATULATIONS: You should now know the basics of python.
#
# Here are the most important concepts, keywords, and functions:
#   1. Import functionality (import, from, as)
#   2. Use basic data types (int,float,str,list)
#   3. Index iterables (indices start at 0, slices end 1 before the end index,
#                       indexing is always performed with square brackets)
#   4. Indent syntax (Colon operator (:) to delineate scope, for, if, elif, else)
#   5. Write and use functions (function definition, doc-string, function use)
